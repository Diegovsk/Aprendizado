from random import randint
n = (randint(0, 10), randint(0, 10), randint(0, 10), randint(0, 10), randint(0, 10))

print(n)
print(f'\nO menor número é: {min(n)}')
print(f'\nO maior número é: {max(n)}')

