from playsound import playsound
playsound('mcpoze80.mp3')