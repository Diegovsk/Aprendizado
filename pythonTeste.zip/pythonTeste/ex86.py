lista = []
for i in range (1,10):
    lista.append(int(input("Número: ")))
for j in range(0,3):
    print(lista[j], "  ", end="")
print("")
for k in range(3,6):
    print(lista[k], "  ", end="")
print("")
for l in range(6,9):
    print(lista[l], "  ", end="")