a = int(input('Digite um valor: '))
ant = a - 1
suc = a + 1
dob = a * 2
tri = a * 3
raiz = a ** (1/2)
print('O antecessor de {} é {}, \nsucessor é {}, \ndobro é {}, \ntriplo é {} e \nraiz é {:.2f} '.format(a, ant, suc, dob, tri, raiz))