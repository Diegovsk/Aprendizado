package com.banco.operacoes;
import java.util.Scanner;
public class Principal {

	private static Scanner sc;
	public static void main(String[] args) {
		int conta, tipo_conta;
		
		
		//objetos
		sc = new Scanner(System.in);
		Operacoes op = new Operacoes();
		Ccorrente cc = new Ccorrente();
		Cinternacional ci = new Cinternacional();
		Cpoupanca cp = new Cpoupanca();
		
		
		
		//como n�o temos um banco de dados, para simular um, temos 2 usuarios com as informa��es pr�-estipuladas
		System.out.println("Ol�, somos o Banco XXXX. Caso voc� seja o usu�rio 1, digite 1, caso seja o usu�rio 2, digite 2, caso 3, digite 3, caso n�o tenha conta, digite 4");
		conta = sc.nextInt();
		switch(conta) {
		case 1: cc.setCpf(07037266175);  
				cc.setNome("Diego");
				cc.setOcupacao("Empres�rio");
				cc.setRg(2008145);
				cc.setSalario(13000);
				
				
				conta_corrente();
				System.out.println(cc.salario + cc.saldo);
		break;
		case 2: ci.setCpf(123456789);  
				ci.setNome("Gushw");
				ci.setOcupacao("Pro player for Free Fire");
				ci.setRg(666999333);
				ci.setSalario(500);
				
				
				conta_internacional();
				    		
		break;
		case 3:cp.setCpf(987654321);
			   cp.setNome("Fulado");
			   cp.setOcupacao("Software Engineer");
			   cp.setRg(7777777);
			   cp.setSalario(4500);
			   
			
			conta_Poupanca();
			
			break;
		case 4: 
			System.out.println("Que tipo de conta deseja criar? 1- Corrente, 2- Internacional, 3- Poupan�a");
			tipo_conta = sc.nextInt();
			if (tipo_conta == 1) {
				System.out.println("Qual � sua idade?");
			    int idade = sc.nextInt();
			    		op.criarConta(idade);
			    		op.setSaldo(0);
			    		conta_corrente();
			    			    		
			}else if (tipo_conta == 2) {
				System.out.println("Qual � sua idade?");
			    int idade = sc.nextInt();
			    		op.criarConta(idade);
			    		op.setSaldo(0);
			    		conta_internacional();
			}else if (tipo_conta == 3) {
				System.out.println("Qual � sua idade?");
			    int idade = sc.nextInt();
			    		op.criarConta(idade);
			    		op.setSaldo(0);
			    		conta_Poupanca();			}
		break;
		}
	}
	//--------------------------------------------------------------------------------------------------------------------------------------------------------
	//criar metodo com o ask
	public static void conta_corrente() {
			Ccorrente cc = new Ccorrente();
			Operacoes op = new Operacoes();
			System.out.println("Agora voc� pode utilizar sua conta.");
    		
    		System.out.println("Gostaria de cotinuar utilizando? 1-Sim  2-N�o");
    		int answer = sc.nextInt();
    		while (answer == 1) {
	    		System.out.println("O que deseja realizar? Digite o n�mero a frente da op��o para realiz�-la. Temos as seguintes op��es: ");
	    		
	    		System.out.println("(1) Pagamentos, (2) empr�stimos, (3) servi�o de cambio, (4) consultar saldo, (5) adicionar dinheiro a conta e (6) Tr�nsfer�ncia de fundos.");
	    		int operacao = sc.nextInt();
	    		switch(operacao) {
	    		case 1: cc.pagamento();
	    		System.out.println("Gostaria de cotinuar utilizando? 1-Sim  2-N�o");
	    		answer = sc.nextInt();
	    			break;
	    		case 2: cc.emprestimo(); 
	    		System.out.println("Gostaria de cotinuar utilizando? 1-Sim  2-N�o");
	    		answer = sc.nextInt();
	    			break;
	    		case 3:// op.cambio();
	    		//System.out.println("Gostaria de cotinuar utilizando? 1-Sim  2-N�o");
	    		//answer = sc.nextInt();
	    			break;
	    		case 4: cc.consultarSaldo();
	    		System.out.println("Gostaria de cotinuar utilizando? 1-Sim  2-N�o");
	    		answer = sc.nextInt();
	    			break;
	    		case 5: cc.inserirDinheiro();
	    		System.out.println("Gostaria de cotinuar utilizando? 1-Sim  2-N�o");
	    		answer = sc.nextInt();
	    			break;
	    		case 6: cc.transfeFundo();
	    		System.out.println("Gostaria de cotinuar utilizando? 1-Sim  2-N�o");
	    		answer = sc.nextInt();
	    			break;
    			
	    		}
    		}
	}
	public static void conta_Poupanca() {
		Cpoupanca cp = new Cpoupanca();
		System.out.println("Agora voc� pode utilizar sua conta.");
		
		System.out.println("Gostaria de cotinuar utilizando? 1-Sim  2-N�o");
		int answer = sc.nextInt();
		while (answer == 1) {
    		System.out.println("O que deseja realizar? Digite o n�mero a frente da op��o para realiz�-la. Temos as seguintes op��es: ");
    		
    		System.out.println("(1) Adicionar dinheiro (2) Consultar saldo (3) Transfer�ncia de fundos (4) Consultar rendimento.");
    		int operacao = sc.nextInt();
    		switch(operacao) {
    		case 1: cp.inserirDinheiro();
    		System.out.println("Gostaria de cotinuar utilizando? 1-Sim  2-N�o");
    		answer = sc.nextInt();
    			break;
    		case 2: cp.consultarSaldo();
    		System.out.println("Gostaria de cotinuar utilizando? 1-Sim  2-N�o");
    		answer = sc.nextInt();
    			break;
    		case 3: cp.transfeFundo();
    		System.out.println("Gostaria de cotinuar utilizando? 1-Sim  2-N�o");
    		answer = sc.nextInt();
    			break;
			
    		}
		}
	}
	public static void conta_internacional() {
		Cinternacional ci = new Cinternacional();
		System.out.println();
		ci.consultarSaldo();
		
	}
}


