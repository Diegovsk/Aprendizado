package com.banco.operacoes;

public class Cpoupanca extends Operacoes {
	Cpoupanca(String nome){
		this.nome = nome;
	}
	Cpoupanca(){
		
	}
	
	public void consultarRendimento() {
		System.out.println("O rendimento atual � de 1,58% ao ano e 0,131% ao m�s.");
	}
}
