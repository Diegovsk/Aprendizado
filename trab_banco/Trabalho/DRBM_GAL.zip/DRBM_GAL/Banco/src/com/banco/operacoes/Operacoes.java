package com.banco.operacoes;

import java.util.Scanner;

public class Operacoes extends Conta {
	Scanner sc = new Scanner(System.in);
	
	private String nomebanco;
	private double numconta;
	
	Operacoes(String nome, String ocupacao,String nomebanco, double cpf, double rg, double salario, int idade, double numconta, double saldo){
		this.cpf = cpf;
		this.rg = rg;
		this.salario = salario;
		this.nome = nome;
		this.ocupacao = ocupacao;
		this.nomebanco = nomebanco;
		this.numconta = numconta;
		this.saldo = saldo;
	}
	
	
	public Operacoes() {
		
	}

	public Scanner getSc() {
		return sc;
	}

	public void setSc(Scanner sc) {
		this.sc = sc;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public String getOcupacao() {
		return ocupacao;
	}

	public void setOcupacao(String ocupacao) {
		this.ocupacao = ocupacao;
	}

	public String getNomebanco() {
		return nomebanco;
	}

	public void setNomebanco(String nomebanco) {
		this.nomebanco = nomebanco;
	}

	public double getCpf() {
		return cpf;
	}

	public void setCpf(double cpf) {
		this.cpf = cpf;
	}

	public double getRg() {
		return rg;
	}

	public void setRg(double rg) {
		this.rg = rg;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public double getNumconta() {
		return numconta;
	}

	public void setNumconta(double numconta) {
		this.numconta = numconta;
	}
	
	
		public void inserirDinheiro() {
			System.out.println("Qual quantia voc� gostaria de colocar no banco?");
			double quantia = sc.nextDouble();
			saldo = saldo + quantia;
		}
	
	
	
        public double consultarSaldo() {
        	System.out.println("Seu saldo � de: "+saldo+" reais");
        	
			return saldo;
		}
			
		public void transfeFundo() {
		System.out.println("Insira o nome do Banco de Destino: ");
		nomebanco = sc.nextLine();
		System.out.println("Insira o numero da conta ");
		numconta = sc.nextDouble();
		saldo = saldo - saldo;
		System.out.println("Tranfer�ncia realizada com sucesso!");
			
		}
		
		public void pagamento() {
			// system out "qual valor do pagamento?"" system in
			//system out "qual cpf ou cpnj beneficiario?" sistem in
			System.out.println("Qual o valor do pagamento?");
			double valor = sc.nextDouble();
			
			if (saldo >= valor) {
				saldo = saldo - valor;
				System.out.println("Seu pagamento foi feito com sucesso! ");
			} else {
				System.out.println("Voc� n�o possui saldo suficiente para esta transa��o.");
			}
		}
		
		
		
		public void emprestimo() {
			System.out.println("Qual o valor do empr�stimo?");
			double valorEmp = sc.nextDouble();
			saldo = saldo + valorEmp;
			System.out.println("A taxa de juros � baixa, apenas 2% ao m�s.");
		}

		
}
