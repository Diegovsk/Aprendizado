package com.banco.operacoes;
import java.util.Scanner;

public abstract class Conta {
	Scanner sc = new Scanner(System.in);
	
	protected String nome, ocupacao;
	protected double cpf, rg, salario, saldo;
	
	
	//eu poderia colocar public abstract void criarConta(int idade);, e escrever o resto no @Override na classe operacoes
	public void criarConta(int idade) {
		if (idade >= 18 ) {
			System.out.println("Insira abaixo seus dados para que possamos prosseguir.");
			System.out.println("Insira seu nome: ");
			nome = sc.nextLine();
			System.out.println("Insira sua ocupacao: ");
			ocupacao = sc.nextLine();
			System.out.println("Insira seu CPF: ");
			cpf = sc.nextDouble();
			System.out.println("Insira seu RG: ");
			rg = sc.nextDouble();
			
		}
		else {
			System.out.println("Desculpe, mas voc� n�o tem a idade m�nima para criar a conta.");
		}
	
	}
	
}
