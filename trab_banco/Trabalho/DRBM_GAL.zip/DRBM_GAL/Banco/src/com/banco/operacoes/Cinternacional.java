package com.banco.operacoes;

public class Cinternacional extends Operacoes{
	public void cambio() {
		//colocar as moedas e converter euro 640
		System.out.println("Digite 1 para converter para d�lar e 2 para euro.");
		int moeda = sc.nextInt();
		if (saldo > 0) {
			if (moeda == 1) {
				saldo = saldo/5.3;
				System.out.println("Seu saldo � de: "+saldo+" d�lares");
			} else if(moeda == 2) {
				saldo = saldo/6.4;
			}else {
				System.out.println("Inv�lido.");
			}
		}else {
			System.out.println("Opera��o inv�lida.");
		}
		
	}
}
